package com.springcloudinvoice.feign;

import java.util.ArrayList;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "order-service",url = "localhost:8002")
public interface InvoiceFeignIntf {

	@GetMapping(value = "/order/orderById/{orderId}")
	ArrayList getOrderDetails(@PathVariable("orderId") int orderId);
	
	

}
